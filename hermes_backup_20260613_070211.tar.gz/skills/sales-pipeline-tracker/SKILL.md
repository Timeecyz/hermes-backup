---
name: Sales Pipeline Tracker
description: Track deals through every stage from lead to close. Manage pipeline stages, update deal status, forecast revenue, and identify bottlenecks in your sales process.
tags: []
related_skills: []
---

# Sales Pipeline Tracker

You are a sales pipeline management assistant. Help the user track deals through their sales pipeline.

## Pipeline Stages
Default stages (customize per user): **Lead → Qualified → Discovery → Proposal → Negotiation → Closed Won / Closed Lost**

## Core Capabilities

### 1. Add a Deal
Ask for: Deal name, company, contact, estimated value, current stage, expected close date, notes.
Format as structured entry.

### 2. Update Deal Stage
Move deals between stages. Always log: date of change, previous stage, new stage, reason for movement.

### 3. Pipeline Summary
When asked, generate a summary showing:
- Total deals per stage
- Total pipeline value
- Weighted pipeline value (Lead: 10%, Qualified: 25%, Discovery: 40%, Proposal: 60%, Negotiation: 80%)
- Deals expected to close this week/month
- Stale deals (no activity >14 days)

### 4. Deal Review
For any deal, provide: time in current stage, next recommended action, risk assessment, competitive notes.

### 5. Win/Loss Analysis
Track closed deals. Calculate: win rate, average deal size, average sales cycle length, top loss reasons.

## Output Format
Use clean tables or structured lists. Always include dates. Keep everything actionable — every update should end with "Next step: ..."

## 蛮子（陈依竹/Claire）定制参数

### 数据源
- **飞书多维表格**：`WXghb4GgCa1NO1sydjIcNCpZn2g`
- **客户总表 table_id**：`tblSroifTqF6xJ6w`
- **App认证**（2026-06-11更新）：
  - App ID: `cli_aaa8bf008738dcdb`
  - App Secret: `L4BS6UnY1CKVkJnWm5jr6eiZq30sZQGz`
- **关键字段**：昵称 / 客户级别 / 意向状态 / 最近联系时间 / 下次联系时间 / 需求类型 / 备注
- **新增字段（2025-05-28）**：跟进记录 / 下次跟进目标 / 跟进紧迫度 / 跟进状态

### ⚠️ 字段可靠性警告（2026-06-11实战发现）
**意向状态字段不可用**：276条记录中约220条为空，不能用来筛选活跃客户。
**正确筛选方式：用 `未来业务价值-客户级别` 字段（B/C/D/E类）。**

| 级别 | 含义 | 优先级 |
|------|------|--------|
| **A类** | 有明确需求，1个月内要签 | 🔴 最高 |
| **B类** | 有意向前还在考虑（1-3个月）| 🟠 高 |
| **C类** | 有需求但还没到时机（3个月+）| 🟡 中期 |
| **D类** | 联系过但没下文了 | 🔴 激活重点 |
| **E类** | 从未联系过，完全空白 | 🟢 破冰最紧急 |

**"无意向状态"客户不等于没有价值** — 44位无意向状态客户中，很多人有B/C/D/E级别，才是真正的可约见客户池。

### 去重逻辑（关键！）
每条物理客户在表中出现约5次（子记录），展示给用户前必须按`昵称`去重：
```python
seen = {}
for r in records:
    name = r.get("fields", {}).get("昵称", "").strip()
    if name and name not in seen:
        seen[name] = r
unique_clients = list(seen.values())
```

### 相关子表
- `tblxOdaFGe1i1j4L` 客户详细信息表：更丰富的个人信息（收入/家庭/病史等），目前子记录较少
- `tblfY4JRoO5vlWDF` 跟进记录表：**目前为空**（0条记录），不要依赖此表做跟进上下文

### 客户分级体系
| 级别 | 含义 | 优先级 | 跟进策略 |
|------|------|--------|---------|
| **A类** | 有明确需求，1个月内要签 | 🔴最高 | 逼单，别让鸭子飞 |
| **B类** | 有意向前还在考虑 | 🟠高 | 持续培养，给理由 |
| **C类** | 有需求但还没到时机 | 🟡中期 | 定期维护，等待时机 |
| **D类** | 联系过但没下文了 | 🔴激活重点 | 发个理由重新搭话 |
| **E类** | 从未联系过 | 🟢最紧急破冰 | 发破冰消息激活 |
| **成交** | 已付款 | 📋售后 | 7天轮转复购/加保 |

### 当前优先级逻辑（2025-06-11修订版）
1. **A类** → 明确需求，直接推，每天推，talk_key="A逼单"
2. **B类** → 有意向且「预计下一次联系时间」已到，talk_key="B促行动"；无时间则主动约
3. **D类** → 联系过没下文，激活，talk_key="D激活"
4. **E类** → 从未联系过，破冰，talk_key="E破冰"
5. 同级别内：跟进紧迫度高的排前面（紧急>正常>可放缓）
6. **"无意向状态"里的B/C/D/E类客户** — 意向状态字段全空，但级别字段有值，这是最大的可约见池

> ⚠️ 实战教训（2026-06-11）：意向状态字段填充率仅约20%（56/276），绝不能依赖意向状态筛选客户。用「未来业务价值-客户级别」字段代替。
> 去重是展示前提：每条记录重复5次（子记录），未去重前永远只有1/5的真实客户数。

### 话术体系（31条，2025-05-28升级）
**按「级别 × 产品」精准匹配**：
- talk_key + 产品方向（如 "A逼单-重疾"、"D激活-储蓄"）
- 无产品关键词 → 降级到 "-通用"（如 "A逼单-通用"）
- 无通用版本 → 降级到 "D激活-通用"

**产品方向识别规则**（needs字段）：
- 含"重疾" → 重疾 | 含"储蓄" → 储蓄 | 含"信托" → 信托 | 含"基金" → 基金

**话术文件位置**：`references/daily_followup.py`（完整可运行脚本）

### 推送格式（2025-05-28升级）
```
🔴 **客户名**
   原因（如：明确需求，本周内签约）
   需求: xxx
   💬 话术内容
   📍 上次: 跟进记录摘要（40字）
   🎯 本次: 下次跟进目标
   📌 备注
```

### 工作流
1. **每天早上自动读飞书** → 筛选今日待跟客户
2. **生成个性化话术** → 破冰/激活/逼单 按级别×产品匹配
3. **推送显示上下文** → 带上上次跟进记录和本次目标
4. **蛮子微信跟进** → 她直接跟进，不改变工具习惯

### ⚠️ 数据质量检查（每次推送前必须检查）
**意向状态填充率仅约20%（56/276），绝不能依赖意向状态筛选客户。**

| 检查项 | 最低要求 | 实际值（2026-06-11） |
|--------|---------|---------------------|
| 意向状态填充率 | >80% | ❌ ~20%（56/276） |
| 最近联系时间填充率 | >70% | ❌ ~2.4% |
| 下次联系时间填充率 | >60% | ❌ 极低 |

**正确做法**：用「未来业务价值-客户级别」字段代替意向状态做筛选。
**备注字段**：部分客户有备注，是目前最可靠的上下文来源。

**数据修复优先级**：
1. 🔴 意向状态 → 先填「未成交/成交」二元状态
2. 🔴 最近联系时间 → 回填历史日期（估计填）
3. 🟠 下次联系时间 → 确认每个客户的下一个行动时间
4. 🟠 跟进记录 → 补关键节点（首次联系/需求确认/方案发送/谈判）

### 新增字段使用指南（蛮子操作流程）
1. 每次跟进完 → 在飞书写「跟进记录」+「下次跟进目标」
2. 设定「跟进紧迫度」：🔴紧急/🟡正常/🟢可放缓
3. 设定「跟进状态」：⏳待联系/✅已跟进/🔁需要再次联系
4. 第二天推送自动带上上下文，你不用重复说上次聊什么

### ⚠️ 工具失败处理（避免轮空追问）
**vision_analyze 对本地图片持续报 404**：不要连赌5次尝试修它。
- 用1次 vision 失败后 → 直接问用户「图片里有什么？」或「图片打不开，直接告诉我也行」
- 不在工具调试上轮转超过2个 turn，用户的描述永远比工具可靠
- 这条规则适用于：图片解析失败、PDF解析失败、网页加载失败 → 统统切「问用户」模式
### 推送超过15人时注明"还有N个客户"并截断

### 数据导入：Excel → 飞书多维表格
**完整流程**见 `references/excel-to-feishu-import.md`，包括：
- 加密 xlsx 解密（`msoffcrypto-tool`）
- Excel 日期 serial → 毫秒时间戳转换
- 字段映射（Excel 列 → 飞书字段，含多选/日期/文本类型区分）
- 去重策略：(姓名小写, 电话后4位)
- 批量导入（每批10条，`batch_create` API）

### 客户名单速查
**完整分类名单**见 `references/客户名单速查-20260611.md`，含99位客户的级别分类、可约见优先顺序、字段可用性说明。

### 注意事项
- 蛮子用微信跟进客户，不改变工具习惯
- 暂不启动售后回访提醒（等潜在客户盘活后再加）
- 每次推送需含「说什么话术」，不只给名字
- 推送超过15人时注明"还有N个客户"并截断