蛮子工作风格：直接给反馈，不兜圈子。先查Notion再给回应，不能没查就说"我来写"或"明天给你初稿"。
§
【客户档案飞书表格】https://liuyufamilyoffice.feishu.cn/base/WXghb4GgCa1NO1sydjIcNCpZn2g（启富未来CRM基底，含客户跟进、获客等数据）
§
蛮子文章改写偏好：改完后直接飞书发给她，不走草稿箱推送。她看完确认后再更新草稿箱。
§
【公众号作者落款】「不躺平的钱」所有文章作者统一写"环球经纪人Claire"
§
【飞书APP凭证】App ID: cli_aa9abc638cf91bb4 | App Secret: 2anV19EgpXL3r14ITxgoug2yatBn2eut
§
蛮子的一个重要特点：她很清楚自己的问题在哪里，但需要在"情绪上头"的瞬间有具体可操作的习惯提示，而不是大道理。她原话是"需要更清晰的习惯提示，让我知道，又能咋情绪上头的时候同时做到这一点"。所以给她建议时，"具体操作步骤"比"分析原因"更重要。她会主动测试工具、给反馈，是一个愿意配合、也在自我进化的用户。
§
蛮子（2026-06-03晚）：我做事经常聊一半跑题、delegate任务没交付、搜东西搜到一半又开新话题。核心教训：接了任务先完成再开新话题，不要边开边忘。
§
日记数据库正确ID：`318cd9aa-41cc-8098-803e-ed230c9c7e80`（NOT `318cd9aa-41cc-80a2-a014-f82b2e49a671`）
§
【工作风格】对系统自动化行为（如standing goal重复注入）感到烦躁，希望我直接说"怎么做"而不是每次都解释。给她解决方案，不要解释原因超过两句话。
§
API/Secret找不到→先搜 ~/.hermes/secret&API.md，搜不到再问蛮子
§
Notion API高频坑：①block_id纯UUID去连字符；②分页has_more+next_cursor；③JSON嵌套报invalid_json宜扁平；④bulleted_list_item的type字段必须正确；⑤**写blocks必须PATCH非POST**；⑥学习库属性全称`文档-命名规则-期数.播客/书籍名字.节目名称.摘抄`
§
【销售核心方法】（Day3 OpenClaw）：逼单四步法「承认事实→表达关心→确认意愿→降低门槛」；咒语「答赞问」（答疑问→赞/共情→追问具体点）「实心认门」（肯定事实→关心→确认→降门槛）；核心理念：销售要有控制感，左右客户决断，把抽象顾虑逼到具体点上。

【蛮子学习方法】2W2H：W1是什么/W2为什么重要/H1怎么运作/H2怎么用（联系客户场景）。学完用2W2H讲给我听，我打分+指盲区。
§
【蛮子学习/工作方式】接了任务先完成再开新话题。2W2H常见问题：①产品名记混（寰宇银活应为环宇盈活）②投保人/持有人/被保人三角色混③H1机制描述角色说错。给指导时直接点破具体错误。
§
【蛮子子女】只有一个儿子：昊总，8岁（11天后满9岁），三年级，成都成华嘉祥外国语学校（私立）。之前说"一个孩子"后又说"搞错了只有一个"——记准：独子。
§
【公众号草稿操作】（2026-06-05）
- AppID+AppSecret在secret&API.md（wx37f93a23f90770b4/c5fc89db461f4de7d55b65091979ce66）
- 读取草稿：`/cgi-bin/draft/batchget` → `/cgi-bin/draft/get?media_id=xxx`
- 「内地人买港险合法吗」media_id: XDSxRVK2ZHBjglHZA5gScWf4MsZuMIDIhhN3QpM2JDr5YAm3Xoy48gzLZw45H1p1
- 草稿总数：24篇，配图已生成4张Midnight Ink提示词待确认
§
【微信读书API Key】wrk-Xe508qCLT1mmtNkaRefYmgAA（主账号，有效期未知，2026-06-07确认。旧key已作废）
§
【微信文章全流程工具】wechat-article-workflow已升级v2(2026-06-07)。关键固化：Python路径/usr/bin/python3、Notion文章库ID(34acd9aa-41cc-818f-aae0-c6ce9e77036f)、4件套标准、Midnight Ink配置、Playwright渲染命令+工作目录/tmp。蛮子发链接+说写文章即可一键跑完全流程。
§
【晚间日记】Notion数据库正确ID: `318cd9aa-41cc-8098-803e-ed230c9c7e80`（Date字段）。飞书DM跨应用open_id错误已知问题(5月底起)。
§
【待确认配图】财富盈活黑金Midnight Ink两规格(21:9主封面+1:1方封面)已完成，待蛮子确认后推进发布流程。