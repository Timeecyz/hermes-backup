# 微信公众号草稿箱 API 操作手册

**创建时间：** 2026-06-05
**验证状态：** ✅ 已验证（成功读取草稿列表 + 单篇内容）

---

## 核心 API 端点

| 操作 | URL | 方法 |
|------|------|------|
| 获取 access_token | `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={APPID}&secret={APPSECRET}` | GET |
| 草稿箱总数 | `https://api.weixin.qq.com/cgi-bin/draft/count?access_token={TOKEN}` | GET |
| 草稿列表 | `https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={TOKEN}` | POST |
| 读取单篇草稿内容 | `https://api.weixin.qq.com/cgi-bin/draft/get?access_token={TOKEN}` | POST |
| 上传永久素材 | `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={TOKEN}&type=image` | POST |
| 推送草稿箱 | `https://api.weixin.qq.com/cgi-bin/draft/add?access_token={TOKEN}` | POST |

---

## Python 操作模板

### 1. 获取 Token

```python
import urllib.request, json

APPID = "wx37f93a23f90770b4"
APPSECRET = "c5fc89db461f4de7d55b65091979ce66"

url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={APPID}&secret={APPSECRET}"
with urllib.request.urlopen(url, timeout=10) as r:
    token = json.load(r)["access_token"]
```

### 2. 读取草稿列表

```python
list_url = f"https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={token}"
payload = json.dumps({"offset": 0, "count": 20, "no_content": 0}).encode()
req = urllib.request.Request(list_url, data=payload,
    headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req, timeout=10) as r:
    drafts = json.load(r)

for item in drafts.get("item", []):
    content = item["content"]["news_item"][0]
    print(f"Title: {content['title']} | Digest: {content['digest']} | Media ID: {item['media_id']}")
```

### 3. 读取单篇草稿全文

```python
media_id = "XDSxRVK2ZHBjglHZA5gScWf4MsZuMIDIhhN3QpM2JDr5YAm3Xoy48gzLZw45H1p1"
get_url = f"https://api.weixin.qq.com/cgi-bin/draft/get?access_token={token}"
payload = json.dumps({"media_id": media_id}).encode()
req = urllib.request.Request(get_url, data=payload,
    headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req, timeout=10) as r:
    full = json.load(r)

news_item = full["news_item"][0]
print(news_item["title"])
print(news_item["content"])  # HTML 格式
```

### 4. 推送草稿（⚠️ 必须用 urllib，不能用 requests）

```python
import urllib.request, json

article = {
    'title': '文章标题',
    'author': 'Claire',
    'digest': '摘要（≤54字）',
    'content': html_content,
    'thumb_media_id': THUMB_MEDIA_ID,
    'need_open_comment': 1,
    'only_fans_can_comment': 0,
}

payload = json.dumps({'articles': [article]}, ensure_ascii=False).encode('utf-8')
req = urllib.request.Request(
    'https://api.weixin.qq.com/cgi-bin/draft/add?access_token=' + token,
    data=payload,
    headers={'Content-Type': 'application/json; charset=utf-8'}
)
result = json.loads(urllib.request.urlopen(req).read())
```

**⚠️ 关键坑：推送必须用 urllib，不能用 requests.post(json=...)——会导致中文乱码（\u 转义）**

---

## 凭证速查

| 字段 | 值 |
|------|-----|
| AppID | wx37f93a23f90770b4 |
| AppSecret | c5fc89db461f4de7d55b65091979ce66 |
| 服务器IP | 111.229.192.217（需加入白名单） |
| 凭证文件 | ~/.hermes/secret&API.md |

---

## 已知坑

1. **中文乱码**：requests.post + json= 参数导致中文变 \u 转义 → 必须用 urllib
2. **IP 不在白名单**：错误码 40164 → 把 111.229.192.217 加入微信公众号后台 → 开发 → 基本配置 → IP白名单
3. **access_token 有效期**：7200秒，每次调用前重新获取
4. **草稿箱总数**：total_count 直接返回 int，不是 dict

---

## 蛮子工作流（已验证 2026-06-05）

1. 用 API 读取草稿箱 → 定位目标文章 → 获取 HTML 内容
2. 分析内容 → 生成配图提示词（Midnight Ink 深色暖金风格）
3. **发飞书给蛮子确认**（不走 wenyan-cli）
4. 蛮子确认后：手动复制到公众号草稿箱 / 或用 API 更新封面图