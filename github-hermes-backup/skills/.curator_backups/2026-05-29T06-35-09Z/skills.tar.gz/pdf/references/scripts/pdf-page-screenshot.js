#!/usr/bin/env node
/**
 * PDF Page Screenshot Extractor
 * Renders PDF pages as JPEG images via Playwright headless browser.
 * Works with vector PDFs where naive image extraction fails.
 *
 * Usage:
 *   node pdf-page-screenshot.js --input /path/to/input.pdf \
 *     --output /path/to/outdir --pages 5-16 --resize-width 800
 *
 * Requirements: npm install pdf-lib sharp playwright
 */

const { chromium } = require('playwright');
const { PDFDocument } = require('pdf-lib');
const sharp = require('sharp');
const http = require('http');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const getArg = (n, def) => { const i=args.indexOf('--'+n); return i>=0?args[i+1]:def; };

const PDF_PATH = getArg('input','');
const OUT_DIR  = getArg('output','/tmp');
const PAGESPEC = getArg('pages','1-10');
const PORT    = parseInt(getArg('port','8765'));
const VIEW_W  = parseInt(getArg('width','1440'));
const JPG_Q   = parseInt(getArg('quality','85'));
const RESIZE_W= parseInt(getArg('resize-width','800'));

if (!PDF_PATH || !fs.existsSync(PDF_PATH)) {
  console.error('Error: --input PDF not found'); process.exit(1);
}

const pages = (() => {
  const [s,e] = PAGESPEC.split('-').map(Number);
  const arr = [];
  for (let i=s; i<=e; i++) arr.push(i);
  return arr;
})();

async function splitPdf() {
  const tmpDir = path.join('/tmp','pdf-pages-'+Date.now());
  fs.mkdirSync(tmpDir,{recursive:true});
  const buf = fs.readFileSync(PDF_PATH);
  const pdf = await PDFDocument.load(buf);
  for (const pg of pages) {
    const idx = pg-1;
    if (idx<0||idx>=pdf.getPages().length) continue;
    const np = await PDFDocument.create();
    const [c] = await np.copyPages(pdf,[idx]);
    np.addPage(c);
    fs.writeFileSync(path.join(tmpDir,`page_${pg}.pdf`), await np.save());
    console.log(`  page ${pg} extracted`);
  }
  return tmpDir;
}

async function screenshot(tmpDir) {
  try { require('child_process').execSync(`fuser -k ${PORT}/tcp 2>/dev/null || true`); } catch(_){}
  const server = http.createServer((req,res)=>{
    const f = path.join(tmpDir, path.basename(req.url));
    if (fs.existsSync(f)) { res.setHeader('Content-Type','application/pdf'); fs.createReadStream(f).pipe(res); }
    else { res.writeHead(404); res.end(); }
  });
  await new Promise(r=>server.listen(PORT,r));
  console.log(`  server on :${PORT}`);
  const browser = await chromium.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--enable-gpu',
      '--disable-dev-shm-usage',
      '--disable-features=IsolateOrigins,site-per-process',
      '--allow-running-insecure-content',
    ]
  });
  for (const pg of pages) {
    const page = await browser.newPage();
    await page.setViewportSize({width:VIEW_W,height:900});
    await page.goto(`http://localhost:${PORT}/page_${pg}.pdf`,{waitUntil:'networkidle',timeout:15000});
    await page.waitForTimeout(1500);
    const shot = await page.screenshot({type:'jpeg',quality:JPG_Q});
    fs.writeFileSync(path.join('/tmp',`raw_p${pg}.jpg`), shot);
    await sharp(path.join('/tmp',`raw_p${pg}.jpg`))
      .resize(RESIZE_W,null,{fit:'inside'}).jpeg({quality:JPG_Q})
      .toFile(path.join(OUT_DIR,`resized_p${pg}.jpg`));
    console.log(`  page ${pg} done`);
    await page.close();
  }
  await browser.close();
  server.close();
}

async function main() {
  console.log(`Pages: ${pages.join(',')} → ${OUT_DIR}`);
  const tmp = await splitPdf();
  await screenshot(tmp);
  fs.rmSync(tmp,{recursive:true,force:true});
  console.log('Done!');
}
main().catch(e=>{console.error(e);process.exit(1);});