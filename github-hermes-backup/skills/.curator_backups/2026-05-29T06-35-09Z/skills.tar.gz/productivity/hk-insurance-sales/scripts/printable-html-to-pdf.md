# HTML → 可打印PDF工作流

## 背景
Hermes环境无PDF生成工具（无wkhtmltopdf/chromium/reportlab/weasyprint，网络下载超时）。

## 推荐方案：HTML + GitHub + 浏览器打印

### 步骤
1. **生成HTML**：使用 `@page { size: A4; margin: 15mm }` CSS打印样式
2. **Push到GitHub**：
   ```bash
   git add <file>.html
   git commit -m "desc"
   GIT_ASKPASS=echo git push https://Timeecyz:ghp_TOKEN@github.com/Timeecyz/<repo>.git main
   ```
3. **用户操作**：打开GitHub链接 → Download → Chrome打开 → Ctrl+P → "另存为PDF"

### GitHub Token格式
- Token类型：Personal Access Token (PAT)
- 格式：`ghp_xxxxxxxxxxxx`
- 存储位置：`~/.hermes/.env` 或 git remote URL嵌入
- 推送前验证：`curl -s https://api.github.com/repos/Timeecyz/<repo> -H "Authorization: token <TOKEN>"`

### GitHub Push防坑
- **GH013错误**（Push protection）：commit内容含secrets → 用`git commit --amend`改写，或分commit推送
- **TLS超时**：网络波动 → 重试git push即可
- **认证失败**：检查token权限（需要repo scope）

### HTML打印样式模板
```html
<style>
  @page {
    size: A4;
    margin: 15mm 15mm 15mm 18mm;
    @bottom-center {
      content: "第 " counter(page) " 页";
      font-size: 9pt;
      color: #999;
    }
  }
  body { font-family: "PingFang SC", sans-serif; max-width: 210mm; }
  .section { page-break-inside: avoid; }
  .page-break { page-break-before: always; }
</style>
```

## 飞书/微信发送HTML文件
- 飞书：`send_message` 工具支持图片/文件，但不支持直接发送HTML附件
- 飞书发文件：需通过文件上传API
- 微信：支持MEDIA格式发送文件

## 备选方案（环境具备时）
- `weasyprint`：Python库，HTML→PDF，本地安装
- `reportlab`：PDF生成，需pip安装
- `browser-use`：playwright/chromium无头浏览器截图转PDF（需--no-sandbox）
