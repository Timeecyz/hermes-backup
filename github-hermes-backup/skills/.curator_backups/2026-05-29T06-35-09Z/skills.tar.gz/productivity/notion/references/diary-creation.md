# 日记创建参考脚本

**用途**：从模板页面复制完整结构，创建当日日记。

## 关键常量

```python
NOTION_TOKEN = "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"
DIARY_DB_ID  = "318cd9aa-41cc-8098-803e-ed230c9c7e80"   # Everyday's Journal
TEMPLATE_ID  = "34acd9aa-41cc-8194-8639-cae39559b759"   # 【模板】2026.4.1
```

## 完整流程

```python
import subprocess, json, datetime, time, requests

NOTION_TOKEN = "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"
HEADERS = {"Authorization": f"Bearer {NOTION_TOKEN}", "Notion-Version": "2022-06-28"}

def run_notion(url, payload, method='POST'):
    """curl + TLS 1.3 — 所有写入操作必须用这个"""
    with open('/tmp/notion_req.json', 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    result = subprocess.run([
        'curl', '-s', '-X', method, url,
        '-H', f'Authorization: Bearer {NOTION_TOKEN}',
        '-H', 'Notion-Version: 2022-06-28',
        '-H', 'Content-Type: application/json; charset=utf-8',
        '--data-binary', '@/tmp/notion_req.json',
        '--tlsv1.3'          # ← 关键！不加这个块写入必败
    ], capture_output=True, text=True)
    return json.loads(result.stdout)

def copy_rich_text(rt_list):
    return [{"type": "text", "text": {"content": t.get('plain_text',''), "link": None}}
            for t in rt_list]

def block_to_dict(blk):
    """将 API 返回的 block 转为可写入格式"""
    bt = blk.get('type')
    raw = blk.get(bt, {})
    base = {"object": "block", "type": bt}
    if bt == 'heading_1':
        base["heading_1"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])), "color": raw.get('color','default')}
    elif bt == 'heading_2':
        base["heading_2"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])), "color": raw.get('color','default')}
    elif bt == 'paragraph':
        base["paragraph"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])), "color": raw.get('color','default')}
    elif bt == 'to_do':
        base["to_do"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])),
                        "checked": raw.get('checked', False), "color": raw.get('color','default')}
    elif bt == 'bulleted_list_item':
        base["bulleted_list_item"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])), "color": raw.get('color','default')}
    elif bt == 'callout':
        base["callout"] = {"rich_text": copy_rich_text(raw.get('rich_text',[])), "icon": raw.get('icon',{}), "color": raw.get('color','default')}
    elif bt == 'divider':
        base["divider"] = {}
    else:
        return None
    return base

# 1. 读取模板（两层：child_page → synced_block → children）
session = requests.Session()
session.headers.update(HEADERS)
tc = session.get(f"https://api.notion.com/v1/blocks/{TEMPLATE_ID}/children?page_size=100").json()['results']
sb_id = tc[0]['id']                                              # synced_block ID
template_inner = session.get(f"https://api.notion.com/v1/blocks/{sb_id}/children?page_size=100").json()['results']

# 2. 创建日记页面
yesterday = datetime.date.today() - datetime.timedelta(days=1)
weekday_map = {0:'一',1:'二',2:'三',3:'四',4:'五',5:'六',6:'日'}
title = f"📓 {yesterday.strftime('%Y.%m.%d')} （周{weekday_map[yesterday.weekday()]}）高能量女孩👧日记📒"

new_page = run_notion("https://api.notion.com/v1/pages", {
    "parent": {"database_id": DIARY_DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": title}}]},
        "Tags": {"multi_select": [{"name": "📓 日记"}]},
        "Date": {"date": {"start": yesterday.isoformat()}},
    }
})
new_page_id = new_page['id']

# 3. 批量写入 blocks（每批 5 个 + 重试）
children = [block_to_dict(b) for b in template_inner if block_to_dict(b)]
for i in range(0, len(children), 5):
    batch = children[i:i+5]
    for retry in range(3):
        r = run_notion(f"https://api.notion.com/v1/blocks/{new_page_id}/children",
                       {"children": batch}, method='PATCH')
        if isinstance(r, dict) and 'results' in r:
            break
        time.sleep(2)
    time.sleep(1)
```

## 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `invalid_request_url` | 缺少 `--tlsv1.3` | 写入时加 `--tlsv1.3` |
| `Connection reset by peer` | TLS 握手失败 | 同上 |
| `invalid_json` | stdin pipe 中文乱码 | 用 `--data-binary @/file.json` |
| 400 `名称 is not a property` | 用错字段名 | 数据库用 `Name`，不是 `名称` |
| 只读到 1 个 block | 模板是 synced_block | 需要两层 GET |
