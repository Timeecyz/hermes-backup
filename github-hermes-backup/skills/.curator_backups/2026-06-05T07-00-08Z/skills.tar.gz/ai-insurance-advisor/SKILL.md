---
name: ai-insurance-advisor
description: 中国大陆保险AI助手。当用户询问以下内容时使用：保险配置、保险方案、产品对比、重疾险/医疗险/寿险/意外险/储蓄险推荐、保费计算、保障缺口分析、需求分析、核保合规、理赔、朋友圈文案、培训话术、代理人展业支持。
---

# AI Insurance Advisor · 保险顾问

## 基本信息

- **name**: ai-insurance-advisor
- **slug**: ai-insurance-advisor
version: 1.8.144
- **tags**: insurance, china, financial, advisor, product-comparison, sales, compliance, agent-assistant, medical, family-protection
- **description**: 中国大陆保险AI助手，为个人和家庭提供全方位的保险咨询、产品对比、方案设计、投保指导。

## 触发关键词

保险咨询、保险配置、保险方案、保险产品对比、保费计算、重疾险、医疗险、寿险、意外险、储蓄险、年金险、两全险、保险理赔、保险代理人、保险话术、朋友圈文案、保障缺口、需求分析、核保、健康告知、投保

## 目标用户

中国大陆有保险需求的个人、家庭

## 工作流程（workflow）

### 主流程

用户发送需求 → 识别意图 → 调用对应脚本/知识库 → 返回结果

### 模块1：保险需求分析

**触发词**：需求分析、保障缺口、家庭保障规划

**执行方式**：
- 对话式收集客户信息：年龄、职业、收入、家庭结构、已有保单、预算
- 调用 `needs_analyzer.py` 分析四大风险：身故、大病、意外、住院
- 输出结构化需求分析报告，包含：风险评分、保障缺口、优先级建议、预算规划

**输入参数**（通过 exec 调用脚本）：
```bash
python3 scripts/needs_analyzer.py
# 或通过 stdin 传入 JSON 参数
```

**输出示例**：
```
- 客户基本信息摘要
- 四大风险分析（身故/大病/意外/住院）
- 保障缺口计算
- 配置优先级排序
- 预算规划建议
```

---