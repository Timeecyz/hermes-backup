【Cron Jobs】
- 晚间天气穿衣提醒: 每天21:00 成都天气+穿衣+孩子校服+限号（川AC073Z周三限行）
- Memory Dreaming Promotion: 每天03:00 短期记忆→长期记忆
- journal-daily-create: 工作日6:45 日记生成

【GitHub备份】
- 仓库: Timeecyz/hermes-backup
- 脚本: ~/.hermes/cron/scripts/hermes_backup.sh
- Token: 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
- Cron: hermes-backup-to-github 每天03:00 (job_id: 8e87306024d2)

【着装风格】周一到周五：西服、衬衫为主的休闲商务风格。孩子校服：周一/周二礼仪校服（配红领巾），周三-周五运动校服。
§
【补充DB】Quick Notes: 318cd9aa-41cc-80a2-a014-f82b2e49a671 | 财经(早报): 35ccd9aa41cc80f2b550e111aeceb6bd
【日记标题emoji】📓笔记本 | 管家点评写入「🏆 小助理の今日总结」模块
【客户录入】先检索同名，重复则合并 | agents默认超时1200s
§
GitHub备份仓库: Timeecyz/-openclaw-workspace (private, 名非openclaw-backup)
备份内容完整: SOUL.md, AGENTS.md, MEMORY.md(77KB), USER.md, IDENTITY.md, TOOLS.md, HEARTBEAT.md, _backup/cron_jobs.json(13个定时任务), _backup/memory/目录(每日记忆+session-corpus)
读取方式: curl -s -H "Authorization: token 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" "https://api.github.com/repos/Timeecyz/-openclaw-workspace/contents/{path}"
§
【蛮子风格参考】Notion文章风格：接地气、有洞察、不鸡汤。核心调性：女生成长/赚钱心智，围绕"想清楚、行动利落、遇事不乱"展开。行文干脆利落，善用数字编号（01/02/03）分段，有锐度有温度，不矫情。以后给蛮子建议参照这个调性。
§
【qifan研学营项目】
- PDF路径(任一皆可): 
  - /home/agentuser/.hermes/cache/documents/doc_ff9bdf78a595_（7月7日发团）启富未来-深港科创亲子研学营4天3晚.pdf (较新, 13:03)
  - /home/agentuser/.hermes/cache/documents/doc_bcf0d09c657a_（7月7日发团）启富未来-深港科创亲子研学营4天3晚.pdf (较早, 11:14)
- HTML路径: /home/agentuser/.hermes/hermes-agent/web/public/qifan/启富未来-研学营-beta版本.html
- 图片目录: /home/agentuser/.hermes/hermes-agent/web/public/qifan/（12张 resized_p5-p16.jpg 待生成）
- 蛮子对图片映射有非常明确的要求，每张图对应哪个PDF页面/内容必须严格匹配，不接受模糊分配
- 预览服务: python3 -m http.server 7890（启动后蛮子自己输入URL预览）
- 图片映射：p5=学生DAY1上, p6=学生DAY1下, p7=学生DAY2上, p8=学生DAY2下, p9=学生DAY3上, p10=学生DAY3下, p11=学生DAY4, p12=家长DAY1上, p13=家长DAY1下, p14=家长DAY2, p15=家长DAY3, p16=家长DAY4
- ⚠️ PDF截图提取：Playwright在Linux无头模式下会触发下载 guard，详见 pdf skill 的 pdf-image-extraction.md。当前环境无Python图像库（pymupdf/pillow均未装），可用Node.js+playwright+sharp方案（需先解决下载guard问题）
§
【蛮子心理哲学】自我调节方法：当很焦虑时，提醒自己"这不过是我30000多天里的其中一天"；当放不下时，提醒自己"这无法影响你未来持续的很多天"。——这是她自己的情绪调节心法，写入会存入Notion"点滴思考"
§
蛮子发来新文件：启富未来-研学营-beta版本_2_.html（新版本，需检查与当前运行版本的差异）