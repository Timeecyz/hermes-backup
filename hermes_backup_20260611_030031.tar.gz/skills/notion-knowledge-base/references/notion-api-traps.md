# Notion API 实战陷阱（2026-06-08）

## 蛮子学习库 DB 属性名（真实值）

DB ID: `349cd9aa-41cc-8017-a0f9-ff07a4a76b7d`

写页面时用这些英文属性 ID，不是中文名：

| 中文显示名 | API 属性名 |
|-----------|-----------|
| 标题 | `文档-命名规则-期数.播客/书籍名字.节目名称.摘抄` |
| 日期 | `Date` |
| 网址 | `网址` |
| Tags | `Tags` |
| 类别 | `类别` |
| 领域 | `领域` |

**错误写法（用中文属性名）：**
```python
"标题": {"title": [{"text": {"content": "..."}}]}, # ❌ 报错
"来源": {"rich_text": [{"text": {"content": "..."}}]},  # ❌ 报错
"日期": {"date": {"start": "2026-06-08"}},             # ❌ 报错
```

**正确写法（用数据库里的实际属性名）：**
```python
"文档-命名规则-期数.播客/书籍名字.节目名称.摘抄": {"title": [{"text": {"content": "..."}}]},
"Date": {"date": {"start": "2026-06-08"}},
"网址": {"url": "https://..."},
"Tags": {"multi_select": [{"name": "Finance"}]},
"类别": {"multi_select": [{"name": "公众号"}]},
"领域": {"multi_select": [{"name": "财经"}]}
```

## 查 DB 有哪些属性的方法

```python
import urllib.request, json
NOTION_TOKEN = "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"
DB_ID = "349cd9aa-41cc-8017-a0f9-ff07a4a76b7d"

req = urllib.request.Request(
    f'https://api.notion.com/v1/databases/{DB_ID}',
    headers={'Authorization': f'Bearer {NOTION_TOKEN}', 'Notion-Version': '2022-06-28'}
)
r = urllib.request.urlopen(req)
db = json.loads(r.read())
for k, v in db['properties'].items():
    print(f"{v['name']}: {k}")
```

## append blocks 正确端点

- ❌ `POST /pages/{id}/blocks` → 400 invalid_request_url
-❌ `POST /pages/{id}/blocks/children` → 400 invalid_request_url
- ✅ `PATCH /blocks/{id}/children`

```python
data = json.dumps({"children": blocks}, ensure_ascii=False).encode('utf-8')
req = urllib.request.Request(
    f'https://api.notion.com/v1/blocks/{PAGE_ID}/children',
    data=data,
    headers={'Authorization': f'Bearer {NOTION_TOKEN}', 
             'Content-Type': 'application/json; charset=utf-8', 
             'Notion-Version': '2022-06-28'}
)
r = urllib.request.urlopen(req)  # PATCH not POST
```

## 写纯文本 block注意事项

bulleted_list_item 里的文字不要含特殊字符（引号等），否则 JSON 解析报错：
- `"content": "不是不让资金出去，而是要求「看得见」的通道"` ✅
- `"content": "不是不让资金出去，而是要求"看得见"的通道"` ❌ 引号嵌套会破坏JSON