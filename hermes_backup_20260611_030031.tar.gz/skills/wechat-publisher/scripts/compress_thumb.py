#!/usr/bin/env python3
"""Compress cover image to WeChat thumb size limit (<64KB)."""
import sys
from PIL import Image

def compress_thumb(src: str, dst: str = None, max_kb: int = 60) -> str:
    dst = dst or src.replace('.png', '_thumb.jpg')
    img = Image.open(src).convert('RGB').resize((900, 386), Image.LANCZOS)
    quality = 85
    while quality > 40:
        img.save(dst, 'JPEG', quality=quality, optimize=True)
        size_kb = dst.stat().st_size // 1024
        if size_kb < max_kb:
            print(f"OK: {dst} → {size_kb}KB (quality={quality})")
            return dst
        quality -= 5
    print(f"WARN: still {size_kb}KB at quality={quality}, may exceed 64KB limit", file=sys.stderr)
    return dst

if __name__ == '__main__':
    src = sys.argv[1] if len(sys.argv) > 1 else 'cover.png'
    compress_thumb(src)