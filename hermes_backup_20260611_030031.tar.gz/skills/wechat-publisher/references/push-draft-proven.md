# 微信公众号草稿推送 — 已验证脚本（2026-06-08, updated 2026-06-10）

## 已验证的工作参数

|字段 | 值 | 字节 |
|------|-----|------|
| title | 财富盈活升级了什么 | 27B |
| author | Claire | 6B |
| title+author 合计 | — | **33B** ✅ |

>⚠️ title+author 必须 ≤33 字节，否则报 45110（author超限）或 45003（title超限）
> 蛮子完整作者名「环球经纪人Claire」需配标题≤12B（4个中文），或用「Claire」配标题≤27B

---

## 完整已验证脚本

```python
# /tmp/push_draft.py  — 直接 python3 /tmp/push_draft.py 运行
import requests, json

APPID = "wx37f93a23f90770b4"
APPSECRET = "c5fc89db461f4de7d55b65091979ce66"

# Step 1: 获取 token（必须带 type=stable）
r = requests.get(
    'https://api.weixin.qq.com/cgi-bin/token',
    params={'grant_type': 'client_credential', 'appid': APPID, 'secret': APPSECRET, 'type': 'stable'},
    timeout=15
)
token = r.json()['access_token']

# Step 2: 从草稿箱找一个已有文章，提取 thumb_media_id
list_url = f'https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={token}'
data = json.dumps({"offset": 0, "count": 20}).encode()
req = requests.post(list_url, data=data, headers={'Content-Type': 'application/json'}, timeout=10)
drafts = req.json()
existing_thumb = drafts["item"][0]['content']['news_item'][0]['thumb_media_id']
# existing_thumb 形如: XDSxRVK2ZHBjglHZA5gScax7xK4UznAH8zCLC6v3rfY1kEPs-pq-7GhSAAxXrHHG

# Step 3: 构造文章（正文用 HTML）
article = {
    "title": "财富盈活升级了什么", # 27B
    "author": "Claire",                 # 6B → 合计33B ✅
    "digest": "财富盈活升级方向钱能拿走传承确定性测评",  # 42B OK
    "content": """<p>友邦6月1日出了新品...</p>""",  # HTML 正文
    "thumb_media_id": existing_thumb,   # 必须是 XDSx... 前缀
    "need_open_comment": 1,
    "only_fans_can_comment": 0
}

# Step 4: 推送草稿
create_url = f'https://api.weixin.qq.com/cgi-bin/draft/add?access_token={token}'
r2 = requests.post(create_url, json={"articles": [article]}, timeout=15)
result = r2.json()
#成功: {"media_id": "XDSx...", "item": [{"index": 0, "ad_count": 0}]}
# 失败: {"errcode": N, "errmsg": "..."}
print(json.dumps(result, indent=2, ensure_ascii=False))
```

---

## 关键错误码排查

| errcode | 含义 | 解决方法 |
|---------|------|---------|
| 40001 | token 无效/过期 | 重新获取 token，有效期7200秒 |
| 40007 | thumb_media_id 无效 | 必须用草稿箱已有的 XDSx... 前缀ID |
| 40066 | URL 无效 | 上传接口地址写错了，核对 endpoint |
| 41005 | media data missing | 正文图片用 `requests.post(url, files={})` |
| 45003 | title 超限 | title_bytes > 27B，缩短标题 |
| 45004 | digest/description 超限 | digest_bytes > ~120B，缩短摘要 |
| 45110 | author 超限 | author_bytes单独超限，或 title+author > 33B |
| 40164 | IP 不在白名单 | 添加 111.229.192.217 到白名单 |

---

## 封面图完整流程（新上传方案 — 2026-06-10验证）

**add_material 上传封面 → 返回 XDSx... 前缀（永久素材）→ 可直接用作 thumb_media_id**

❌ 旧说法「add_material 返回 f61mr... 前缀」是错的。f61mr 是 `media/upload` 临时素材的前缀；`add_material` 返回的是 XDSx... 前缀的永久素材，才是 thumb_media_id 需要的格式。

```python
# 正确流程（2026-06-10验证成功）：
from PIL import Image
import urllib.request, json

# 1. PIL 压缩封面图到 <64KB
img = Image.open('cover.png').convert('RGB')
img.resize((900, 386), Image.LANCZOS).save('cover_thumb.jpg', 'JPEG', quality=70, optimize=True)

# 2. urllib multipart 上传到 add_material
upload_url = "https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=" + token + "&type=image"
boundary = "----FormBoundary7MA4YWxkTrZu0gW"
with open("cover_thumb.jpg", "rb") as f:
    img_data = f.read()
header = ("--" + boundary + "\r\n"
          "Content-Disposition: form-data; name=\"media\"; filename=\"cover.jpg\"\r\n"
          "Content-Type: image/jpeg\r\n\r\n").encode()
footer = ("\r\n--" + boundary + "--\r\n").encode()
body = header + img_data + footer
req = urllib.request.Request(upload_url, data=body)
req.add_header('Content-Type', 'multipart/form-data; boundary=' + boundary)
result = json.loads(urllib.request.urlopen(req).read())
new_thumb = result['media_id']  # XDSx... 前缀，直接用于 thumb_media_id
```

⚠️ **已知坑：draft/batchget 返回的 thumb_media_id 可能是空字符串**

某些旧草稿（尤其是通过微信后台编辑过的）thumb_media_id 字段为空字符串。盲目复用会报 40007。**必须**：上传新封面图获取新的 XDSx... 前缀 media_id，再用于 draft/add。

---

## Notion 状态更新

草稿发布成功后，同步更新 Notion 文章库状态：
```
PATCH https://api.notion.com/v1/pages/{PAGE_ID}
{"properties": {"状态": {"select": {"name": "已发布"}}}}
```