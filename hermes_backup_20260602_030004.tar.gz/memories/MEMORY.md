Token: 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 | Notion: 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
§
【Notion数据库速查】
- 读书+播客+课程学习内容笔记（AI学习/播客读书）: 349cd9aa-41cc-8017-a0f9-ff07a4a76b7d
- 每日财经资讯存储（无标签字段）: 35ccd9aa-41cc-80f2-b550e111aeceb6bd
- 蛮子日记: 318cd9aa-41cc-80a2-a014-f82b2e49a671
- Quick Notes: 318cd9aa-41cc-80a2-a014-f82b2e49a671
- 启富未来CRM: https://liuyufamilyoffice.feishu.cn/base/WXghb4GgCa1NO1sydjIcNCpZn2g
§
【工作风格】蛮子说目标/方向，不说过程，我来拆解执行。"成年人不做选择，AI流程就是要不断优化"。输出原则：给信息先说「有什么用」，不要全文总结。【升级防护】蛮子痛点：OpenClaw升级后对话和配置全丢，很抗拒反复调试系统。HERMES升级只动主程序，数据在~/.hermes/外围，风险低。要求：升级后记录版本快照，GitHub备份覆盖所有关键文件。
§
【蛮子风格参考】Notion文章风格：接地气、有洞察、不鸡汤。核心调性：女生成长/赚钱心智，围绕"想清楚、行动利落、遇事不乱"展开。行文干脆利落，善用数字编号（01/02/03）分段，有锐度有温度，不矫情。以后给蛮子建议参照这个调性。
§
fal.ai API key: b3cdc6f5-4451-4fce-ae77-de9405b0b344 / 253e6030633d7eac5ef311cc0a7476c9
§
【蛮子心理哲学】自我调节方法：当很焦虑时，提醒自己"这不过是我30000多天里的其中一天"；当放不下时，提醒自己"这无法影响你未来持续的很多天"。——这是她自己的情绪调节心法，写入会存入Notion"点滴思考"
§
【研学营项目】qifan HTML已更新至beta_2_版本，图片路径已修复（/resized_p5.jpg），HTTP服务器正常，但飞书分享时微信内嵌浏览器可能无法显示图片。
§
【公众号配图】凹版版画风格（铜版颗粒质感+0.8mm外轮廓+0.1mm内部精细线）。工具：豆包/即梦App生成图，我负责上传推送+叠加中文。fal.ai中文渲染差，已弃用。
§
【研学营配图】蛮子对图片美观度要求高，fal.ai 中文渲染不行（草书乱码），PIL 渲染字体正确但设计丑。豆包生成的图她认为好看。后续配图建议：1）让蛮子用豆包生成，我负责排版+文字叠加；2）或换成 DALL-E 3/即梦等工具
§
【飞书API排错】文档类型判断：飞书电子表格（sheets/spreadsheet）≠ 多维表格（bitable），前者用 sheets/v3/spreadsheets API，需要单独申请 sheets:spreadsheet 权限。遇到 99991672 错误码 = 缺权限，需在应用权限页开通。
§
【客户档案飞书表格】https://liuyufamilyoffice.feishu.cn/base/WXghb4GgCa1NO1sydjIcNCpZn2g（启富未来CRM基底，含客户跟进、获客等数据）
§
蛮子的产品/项目：启富未来研学营（beta_2版本HTML手册已收到，位于 ~/.hermes/cache/documents/）
§
热点+公众号改写工作流已跑通：搜数据→写文（15模块Claire结构）→生成配图提示词→本地存档→推草稿箱。蛮子确认流程OK，承诺后续沿用。
§
【晨报悬案回顾】工作日6:50自动运行（job_id: d9ffde91cc16），扫描昨天对话记录，识别悬而未决的事，推送给蛮子并写入Notion Quick Notes（DB: 318cd9aa-41cc-80a2-a014-f82b2e49a671）
§
【公众号作者落款】「不躺平的钱」所有文章作者统一写"环球经纪人Claire"
§
【飞书APP凭证】App ID: cli_aa9abc638cf91bb4 | App Secret: 2anV19EgpXL3r14ITxgoug2yatBn2eut
§
蛮子的一个重要特点：她很清楚自己的问题在哪里，但需要在"情绪上头"的瞬间有具体可操作的习惯提示，而不是大道理。她原话是"需要更清晰的习惯提示，让我知道，又能咋情绪上头的时候同时做到这一点"。所以给她建议时，"具体操作步骤"比"分析原因"更重要。她会主动测试工具、给反馈，是一个愿意配合、也在自我进化的用户。