#!/usr/bin/env python3
"""
公众号热点雷达 - 每日自动扫描+Notion存储+飞书推送
专为"不躺平的钱"账号定制

数据源:
  - 百度热搜主榜
  - 百度热搜财经榜（高价值财经垂直热点）
  - B站热门视频
  - 百度新闻搜索（法律/税务/CRS等关键词主动搜索）
"""

import subprocess, json, time, sys, os, re
from datetime import datetime

# ── 配置区 ──────────────────────────────────────────
APP_ID = "cli_aa9abc638cf91bb4"
APP_SECRET = "2anV19EgpXL3r14ITxgoug2yatBn2eut"
FEISHU_CHAT_ID = "oc_a56f81c068904e887d22ed102283b66d"

NOTION_KEY = "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"
NOTION_HOT_DB = "34acd9aa-41cc-818f-aae0-c6ce9e77036f"

# 过滤关键词（按优先级排序，命中即保留）
FILTER_KEYWORDS = [
    # 高优先级：香港保险相关
    "香港保险", "跨境理财", "香港银行卡", "香港保单", "香港金融中心",
    # 核心关键词
    "保险", "理财", "存款", "赚钱", "养老", "退休", "香港", "储蓄",
    "女性养老金", "金钱心理学", "投资认知",
    # 蛮子新增
    "法律", "税务", "CRS", "资产配置", "遗产税", "房产税",
    "婚姻财产", "财富传承", "家族信托", "离岸资产",
    # 扩展财经
    "基金", "股票", "国债", "外汇", "加密货币",
    "财务自由", "被动收入", "副业", "FIRE",
]

# ── 工具函数 ────────────────────────────────────────
def curl(url, ua="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", referer="", timeout=12):
    try:
        cmd = ["curl", "-s", "--max-time", str(timeout), "-A", ua]
        if referer:
            cmd += ["-H", f"Referer: {referer}"]
        cmd += ["-H", "Accept: application/json, text/plain, */*"]
        cmd.append(url)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 5)
        return r.stdout.strip()
    except Exception as e:
        return ""

def get_feishu_token():
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
         "-H", "Content-Type: application/json; charset=utf-8",
         "-d", json.dumps({"app_id": APP_ID, "app_secret": APP_SECRET})],
        capture_output=True, text=True, timeout=15
    )
    try:
        d = json.loads(r.stdout)
        return d.get("tenant_access_token", "")
    except:
        return ""

def feishu_send(token, text, chat_id):
    payload = json.dumps({
        "receive_id": chat_id,
        "msg_type": "text",
        "content": json.dumps({"text": text})
    }, ensure_ascii=False)
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id",
         "-H", f"Authorization: Bearer {token}",
         "-H", "Content-Type: application/json; charset=utf-8",
         "-d", "@-"],
        input=payload, capture_output=True, text=True, timeout=15
    )
    try:
        d = json.loads(r.stdout)
        return d.get("code") == 0
    except:
        return False

def notion_search(keyword, db_id):
    """检查Notion DB中是否已有此关键词条目（前15字匹配）"""
    query = json.dumps({
        "filter": {
            "property": "名称",
            "title": {"contains": keyword[:15]}
        },
        "page_size": 1
    }, ensure_ascii=False)
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         f"https://api.notion.com/v1/databases/{db_id}/query",
         "-H", f"Authorization: Bearer {NOTION_KEY}",
         "-H", "Notion-Version: 2022-06-28",
         "-H", "Content-Type: application/json; charset=utf-8",
         "-d", "@-"],
        input=query, capture_output=True, text=True, timeout=15
    )
    try:
        d = json.loads(r.stdout)
        return len(d.get("results", [])) > 0
    except:
        return False

def notion_append(db_id, title, url, platform, hot_val, tags, angle):
    """写入Notion热点库"""
    page = {
        "parent": {"database_id": db_id},
        "properties": {
            "名称": {"title": [{"text": {"content": title[:200]}}]},
            "状态": {"select": {"name": "热点捕捉"}},
            "类型": {"select": {"name": "热点"}},
            "标签": {"multi_select": [{"name": t} for t in tags]},
            "负责人": {"select": {"name": "Claire CHEN"}},
        },
        "children": [
            {"object": "block", "type": "heading_3", "heading_3": {"rich_text": [{"type": "text", "text": {"content": "📡 数据来源"}}]}},
            {"object": "block", "type": "paragraph", "paragraph": {"rich_text": [{"type": "text", "text": {"content": f"平台：{platform}  |  热度值：{hot_val}"}}]}},
            {"object": "block", "type": "heading_3", "heading_3": {"rich_text": [{"type": "text", "text": {"content": "🔗 原文链接"}}]}},
            {"object": "block", "type": "paragraph", "paragraph": {"rich_text": [{"type": "text", "text": {"content": url if url else "无"}}]}},
            {"object": "block", "type": "heading_3", "heading_3": {"rich_text": [{"type": "text", "text": {"content": "💡 切入点建议"}}]}},
            {"object": "block", "type": "paragraph", "paragraph": {"rich_text": [{"type": "text", "text": {"content": angle}}]}},
            {"object": "block", "type": "heading_3", "heading_3": {"rich_text": [{"type": "text", "text": {"content": "⏰ 捕捉时间"}}]}},
            {"object": "block", "type": "paragraph", "paragraph": {"rich_text": [{"type": "text", "text": {"content": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}}]}},
        ]
    }
    payload = json.dumps(page, ensure_ascii=False)
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         "https://api.notion.com/v1/pages",
         "-H", f"Authorization: Bearer {NOTION_KEY}",
         "-H", "Notion-Version: 2022-06-28",
         "-H", "Content-Type: application/json; charset=utf-8",
         "-d", "@-"],
        input=payload, capture_output=True, text=True, timeout=15
    )
    try:
        d = json.loads(r.stdout)
        return d.get("id") is not None
    except:
        return False

def matches_filter(title):
    """检查标题是否命中过滤词，按优先级返回（None或命中的词）"""
    t = title.lower()
    for kw in FILTER_KEYWORDS:
        if kw.lower() in t:
            return kw
    return None

def match_priority(title):
    """返回标题命中的最高优先级索引（数字越小优先级越高）"""
    t = title.lower()
    for i, kw in enumerate(FILTER_KEYWORDS):
        if kw.lower() in t:
            return i
    return 999

def suggest_angle(title, hit_kw=None):
    """基于热点标题和命中的关键词给出切入角度建议"""
    kw = hit_kw or ""

    if kw in ["香港保险", "香港保单"]:
        return f"【香港保险】你的专业领域，适合写深度产品解析+对比优势"
    elif kw in ["跨境理财", "香港银行卡", "香港金融中心"]:
        return f"【跨境理财】跨境资金配置角度切入，结合香港账户开户实操"
    elif kw in ["女性养老金"]:
        return f"【女性养老金】从「女性财务规划特殊性」切入，呼应独立养老趋势"
    elif kw in ["金钱心理学", "投资认知"]:
        return f"【投资认知】从「行为金融学」角度切入，普通人常见认知偏差"
    elif kw == "香港":
        return f"【香港金融】结合香港国际金融中心地位，讲跨境配置机会"
    elif kw in ["保险", "理财", "存款", "储蓄"]:
        return f"【理财科普】「{title}」— 从「普通人如何配置」角度切入"
    elif kw in ["养老", "退休"]:
        return f"【养老规划】结合保险产品讲透「为什么越早规划越划算」"
    elif kw in ["赚钱"]:
        return f"【赚钱思维】适合写「赚钱和认知的关系」，结合你的一线销售经验"
    elif kw == "法律":
        return f"【法律视角】从「普通人必知的法律常识」切入，实用性强"
    elif kw == "税务":
        return f"【税务规划】从「合理避税/合法节税」角度切入，高净值读者关心"
    elif kw == "CRS":
        return f"【CRS/海外账户】从「全球税务透明化对内地居民的影响」切入"
    elif kw in ["遗产税", "房产税"]:
        return f"【财富传承】从「税改趋势下的资产保全策略」切入"
    elif kw in ["婚姻财产", "家族信托", "财富传承"]:
        return f"【财富传承】结合实际案例，讲「如何把财富安全留给下一代」"
    elif kw in ["离岸资产", "资产配置"]:
        return f"【跨境资产配置】结合香港保险/海外账户，讲全球分散风险"
    elif kw in ["基金", "股票", "国债", "外汇", "加密货币"]:
        return f"【投资理财】「{title}」— 从「普通人该不该配置」角度切入"
    elif kw in ["财务自由", "被动收入", "FIRE"]:
        return f"【财务自由】从「FIRE运动/被动收入」切入，呼应搞钱群体"
    elif kw == "副业":
        return f"【副业赚钱】从「主业+副业双轨收入」切入，结合你的销售经验"
    else:
        return f"【待定】需进一步评估，可结合「财务自由/赚钱心智」展开"

# ── 平台数据采集 ────────────────────────────────────
def collect_baidu():
    """采集百度热搜（主榜+财经榜）"""
    items = []
    # 主榜
    html = curl("https://top.baidu.com/board")
    if html and len(html) > 500:
        queries = re.findall(r'"query":"([^"]{4,60})"', html)
        scores = re.findall(r'"hotScore":"([0-9]+)"', html)
        for i in range(min(len(queries), len(scores), 30)):
            items.append({
                "title": queries[i],
                "hot_value": scores[i] if i < len(scores) else "-",
                "platform": "百度",
                "url": ""
            })
    # 财经榜（高价值财经垂直热点）
    html2 = curl("https://top.baidu.com/board?tab=finance")
    if html2 and len(html2) > 500:
        queries2 = re.findall(r'"query":"([^"]{4,60})"', html2)
        scores2 = re.findall(r'"hotScore":"([0-9]+)"', html2)
        for i in range(min(len(queries2), len(scores2), 30)):
            items.append({
                "title": queries2[i],
                "hot_value": scores2[i] if i < len(scores2) else "-",
                "platform": "百度财经",
                "url": ""
            })
    return items

def collect_bilibili():
    """采集B站热门视频前20"""
    items = []
    try:
        r = subprocess.run(
            ["curl", "-s", "--max-time", "12",
             "https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&type=all",
             "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"],
            capture_output=True, text=True, timeout=15
        )
        d = json.loads(r.stdout)
        for item in d.get("data", {}).get("list", [])[:20]:
            title = item.get("title", "").replace("<em>", "").replace("</em>", "")
            if title:
                short_link = item.get("short_link_v2", "")
                items.append({
                    "title": title,
                    "hot_value": "-",
                    "platform": "B站",
                    "url": f"https://b23.tv/{short_link}" if short_link else ""
                })
    except:
        pass
    return items

def collect_baidu_news(keyword, max_results=8):
    """
    通过百度新闻搜索采集指定关键词的最新资讯
    专门解决：法律/税务/CRS/遗产税等niche关键词不上热搜的问题
    """
    items = []
    try:
        # 百度新闻搜索结果页
        encoded_kw = keyword.replace(" ", "+")
        url = f"https://www.baidu.com/s?wd={encoded_kw}+新闻&rn=20&tn=news&ie=utf8"
        html = curl(url, timeout=15)
        if not html or len(html) < 200:
            return items

        # 从搜索结果中提取新闻标题（百度新闻结果格式）
        # 格式1: 普通搜索结果标题
        titles = re.findall(r'class="news-title[^"]*"[^>]*>([^<]+)<', html)
        if not titles:
            # 格式2: 带链接的标题
            titles = re.findall(r'<a[^>]+class="[^\"]*title[^\"]*"[^>]*>([^<]{5,80})</a>', html)
        if not titles:
            # 格式3: h3标题
            titles = re.findall(r'<h3[^>]*>\s*<a[^>]*>([^<]{5,80})</a>', html)
        if not titles:
            # 格式4: 通用a标签（新闻类）
            titles = re.findall(r'<a[^>]+>([^<]{5,80}?(?:法|税|CRS|资产|财富|保险|理财)[^<]{0,30})</a>', html)

        for t in titles[:max_results]:
            t = t.strip()
            t = re.sub(r'<[^>]+>', '', t).strip()
            if t and len(t) > 5:
                items.append({
                    "title": t,
                    "hot_value": "-",
                    "platform": f"百度新闻:{keyword}",
                    "url": ""
                })
    except Exception as e:
        pass
    return items

def collect_weibo_via_search():
    """通过微博搜索接口采集热搜关键词（备用）"""
    items = []
    try:
        r = subprocess.run(
            ["curl", "-s", "--max-time", "12",
             "https://s.weibo.com/realtime?Refer=hotband",
             "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
             "-H", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"],
            capture_output=True, text=True, timeout=15
        )
        html = r.stdout
        titles = re.findall(r'class="name_text">([^<]+)</span>', html)
        for t in titles[:20]:
            t = t.strip()
            if t and len(t) > 3:
                items.append({
                    "title": t,
                    "hot_value": "-",
                    "platform": "微博",
                    "url": f"https://s.weibo.com/weibo?q={t}"
                })
    except:
        pass
    return items

# ── 主程序 ──────────────────────────────────────────
def main():
    print(f"🔥 热点雷达启动 | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    all_items = []

    # ── 基础数据源 ──
    print("📡 采集百度热搜...")
    all_items.extend(collect_baidu())
    time.sleep(0.3)

    print("📡 采集B站热门...")
    all_items.extend(collect_bilibili())
    time.sleep(0.3)

    # ── 百度新闻主动搜索（法律/税务/CRS等niche关键词）───
    niche_keywords = [
        "法律", "税务", "CRS", "遗产税", "房产税",
        "婚姻财产", "财富传承", "家族信托", "离岸资产",
        "资产配置", "财务自由", "副业",
    ]
    print("📡 采集百度新闻主动搜索...")
    for kw in niche_keywords:
        news_items = collect_baidu_news(kw, max_results=5)
        all_items.extend(news_items)
        if news_items:
            print(f"   [{kw}] 采集到 {len(news_items)} 条")
        time.sleep(0.4)

    # ── 备用：微博热搜 ──
    print("📡 采集微博热搜（备用）...")
    weibo_items = collect_weibo_via_search()
    all_items.extend(weibo_items)
    print(f"   微博 {len(weibo_items)} 条")

    print(f"\n共采集 {len(all_items)} 条")

    # ── 过滤+排序 ──
    filtered = []
    for it in all_items:
        hit = matches_filter(it["title"])
        if hit:
            it["_hit_kw"] = hit
            it["_priority"] = match_priority(it["title"])
            filtered.append(it)
    filtered.sort(key=lambda x: x["_priority"])

    # 去重（按标题前30字）
    seen = {}
    unique_filtered = []
    for it in filtered:
        key = it["title"][:30].lower()
        if key not in seen:
            seen[key] = True
            unique_filtered.append(it)
    filtered = unique_filtered

    print(f"过滤后 {len(filtered)} 条（已去重，按关键词优先级排序）")

    # ── 飞书推送 ──
    token = get_feishu_token()
    if not token:
        print("❌ 获取飞书token失败")
        return

    if not filtered:
        feishu_send(token,
            f"🔥 今日热点雷达 | {datetime.now().strftime('%m月%d日 %H:%M')}\n\n"
            f"今日未发现保险/理财/赚钱相关热点。\n"
            f"💡 建议从「赚钱心智」「香港保险」「养老规划」角度储备常规选题。",
            FEISHU_CHAT_ID)
        print("空报已发送")
        return

    top5 = filtered[:5]

    now = datetime.now().strftime("%m月%d日 %H:%M")
    lines = [f"🔥 今日热点雷达 | {now}\n"]
    lines.append(f"共扫描{len(all_items)}条，命中{len(filtered)}条，展示TOP{len(top5)}：\n")
    lines.append("─" * 22)

    notion_saved = 0

    for i, item in enumerate(top5, 1):
        title = item["title"]
        hit_kw = item.get("_hit_kw", "")
        angle = suggest_angle(title, hit_kw)
        platform = item["platform"]
        hot = item.get("hot_value", "-")
        hit_tag = f"[{hit_kw}]" if hit_kw else ""

        lines.append(f"\n{i}. {hit_tag}「{title}」")
        lines.append(f"   平台：{platform}  热度：{hot}")
        lines.append(f"   💡 {angle}")

        # 去重写入Notion
        if not notion_search(title[:15], NOTION_HOT_DB):
            tags = []
            if hit_kw in ["香港保险", "香港保单", "跨境理财", "香港银行卡", "香港金融中心"]:
                tags.append("香港保险")
            elif hit_kw in ["保险", "理财", "存款", "储蓄"]:
                tags.append("理财保险")
            elif hit_kw in ["养老", "退休"]:
                tags.append("养老规划")
            elif hit_kw == "女性养老金":
                tags.append("女性成长")
            elif hit_kw in ["金钱心理学", "投资认知"]:
                tags.append("投资认知")
            elif hit_kw == "香港":
                tags.append("香港金融")
            elif hit_kw == "赚钱":
                tags.append("赚钱心智")
            elif hit_kw in ["法律", "税务", "CRS", "遗产税", "房产税"]:
                tags.append("法律税务")
            elif hit_kw in ["婚姻财产", "家族信托", "财富传承", "离岸资产"]:
                tags.append("财富传承")
            elif hit_kw in ["资产配置", "基金", "股票", "国债", "外汇", "加密货币"]:
                tags.append("投资理财")
            elif hit_kw in ["财务自由", "被动收入", "副业", "FIRE"]:
                tags.append("赚钱心智")
            else:
                tags.append("综合热点")

            ok = notion_append(NOTION_HOT_DB, title, item["url"],
                               platform, hot, tags, angle)
            if ok:
                notion_saved += 1
            time.sleep(0.3)

    lines.append(f"\n─" * 22)
    lines.append(f"✅ 已存入Notion热点库（{notion_saved}条新内容）")
    lines.append(f"📋 查看：https://www.notion.so/34acd9aa41cc818faae0c6ce9e77036f")
    lines.append(f"\n回复「写公众号+数字」启动写作（如：写公众号1）")

    msg = "\n".join(lines)
    print("\n" + msg)

    ok = feishu_send(token, msg, FEISHU_CHAT_ID)
    print(f"\n飞书推送: {'✅ 成功' if ok else '❌ 失败'}")

if __name__ == "__main__":
    main()
