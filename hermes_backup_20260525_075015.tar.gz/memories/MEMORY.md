用户称呼: 蛮子 | 职业: 保险与财富管理（内地/港险/财富管理/信托/客户营销/裂变）

【身份设定】生活大管家 🏠 — 主动不打扰、统筹不包办、贴心有边界

【用户偏好】
- 输出: 重点突出/清单化/可直接用, 结构化避免长段落
- 工具: 飞书多维表格+日历, 微信推送 (openclaw-weixin)
- 提醒: 早7:30 / 晚21:00
- 运动: 力量训练17:00-18:30 / 有氧6:30-7:15（早上不主动问训练）
- 禁忌: 22:00后不打扰, 不主动改已确认日程, 不推未经核实数据, 不介入私人领域

【Cron Jobs】
- daily-evening-summary: 每天21:00 晚间总结（飞书日历+明日提醒+孩子牙线提醒）
- 晚间天气穿衣提醒: 每天21:00 成都天气+穿衣+孩子校服+限号（川AC073Z周三限行）
- Memory Dreaming Promotion: 每天03:00 短期记忆→长期记忆
- journal-daily-create: 工作日6:45 日记生成

【Subagents】health-expert(健康管理) / investment-expert(投资研究) / sales-coach(销售教练)

【Notion #指令系统】
- #记日记 → Journal 318cd9aa-41cc-8098-803e-ed230c9c7e80
- #记香港保险卖点 → 358cd9aa-41cc-80e0-8d2f-d03b1e329bf2
- #财务盘点 → 355cd9aa-41cc-8183-a037d8150b1875f7
- #健康生活 → 35ccd9aa-41cc-8059-ada1fc207630994c
- #AI学习 → 319cd9aa-41cc-80278b18e950fc22e72e
- #高能量女孩素材 → 35ccd9aa-41cc-8069b696c6cec7aa5654
- #客户方案 → 34acd9aa-41cc-812b-baa2-eab1af1e55c0
- #港险学习资料 → 34acd9aa-41cc-8171-b23a-db671429219c
- #不躺平公众号 → 34acd9aa-41cc-818f-aae0-c6ce9e77036f（存完整版+三件套）
- Notion API: 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

【日记模板】Page ID: 34acd9aa-41cc-8194-8639-cae39559b759
- 标题: xxxx.x.xx 📓高能量女孩👧日记📒
- 结构: Thoughts→Have Done→To Do→Be Grateful→Work out→Diets→17项打卡→小助理总结

【17项打卡】1.Clients 2h 2.Financial studies 1h 3.Macro News 1h 4.AI Study 1h 5.Reading 30min 6.Writing 15min⁺ 7.Workout 30min⁺ 8.Duolingo⁺ 9.English 15min⁺ 10.Nap 15min⁺ 11.Water 2200⁺ 12.Meditation 5min⁺ 13.Kegel 5min⁺ 14.Supplements 15.BETTER ME? 16.BENEFIT SOCIETY? 17.SYSTEM DRIVEN?（未完成不迁移次日）

【港险提取密码】125=1年缴/第2年起/5%/年；556=5年缴/第5年末/6%；567=5年缴/第6年末/7%

【保险缴费2026】1/8¥60k中意(周恒玉) | 6/10¥1,400瑞泰(段谦) | 7/2¥3,237段鸣昊重疾 | 7/3¥3,237阳光(段谦) | 7/7¥3,686复星联合(蛮子)

【固定支出】停车¥810/月(华润300+汇融450+成大60) | 电话¥347/月(电信199+移动148)

【核心营销规则】营销闭环: 前端→线索→跟进→成交→售后→老客→转介绍
- 客户分级: 高意向=每日跟进, 中意向=3天跟进, 低意向=1周跟进, 老客=每月维系
- 合规底线: 禁止"保本""稳赚""零风险"; 港险需提示监管/汇率/税务差异

【客户-白玛师姐】跟进状态:5.23面谈未成交,转介绍未发出; 资金锁Pre-IPO,需求不匹配,成交概率10%; Notion: https://www.notion.so/36acd9aa41cc81ae81d8eca7bac726da
§
【补充DB】Quick Notes: 318cd9aa-41cc-80a2-a014-f82b2e49a671 | 财经(早报): 35ccd9aa41cc80f2b550e111aeceb6bd
【日记标题emoji】📓笔记本 | 管家点评写入「🏆 小助理の今日总结」模块
【客户录入】先检索同名，重复则合并 | agents默认超时1200s