# 微信公众号草稿推送 — 已验证脚本（2026-06-08）

## 已验证的工作参数

|字段 | 值 | 字节 |
|------|-----|------|
| title | 财富盈活升级了什么 | 27B |
| author | Claire | 6B |
| title+author 合计 | — | **33B** ✅ |

>⚠️ title+author 必须 ≤33 字节，否则报 45110（author超限）或 45003（title超限）
> 蛮子完整作者名「环球经纪人Claire」需配标题≤12B（4个中文），或用「Claire」配标题≤27B

---

## 完整已验证脚本

```python
# /tmp/push_draft.py  — 直接 python3 /tmp/push_draft.py 运行
import requests, json

APPID = "wx37f93a23f90770b4"
APPSECRET = "c5fc89db461f4de7d55b65091979ce66"

# Step 1: 获取 token（必须带 type=stable）
r = requests.get(
    'https://api.weixin.qq.com/cgi-bin/token',
    params={'grant_type': 'client_credential', 'appid': APPID, 'secret': APPSECRET, 'type': 'stable'},
    timeout=15
)
token = r.json()['access_token']

# Step 2: 从草稿箱找一个已有文章，提取 thumb_media_id
list_url = f'https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={token}'
data = json.dumps({"offset": 0, "count": 20}).encode()
req = requests.post(list_url, data=data, headers={'Content-Type': 'application/json'}, timeout=10)
drafts = req.json()
existing_thumb = drafts["item"][0]['content']['news_item'][0]['thumb_media_id']
# existing_thumb 形如: XDSxRVK2ZHBjglHZA5gScax7xK4UznAH8zCLC6v3rfY1kEPs-pq-7GhSAAxXrHHG

# Step 3: 构造文章（正文用 HTML）
article = {
    "title": "财富盈活升级了什么", # 27B
    "author": "Claire",                 # 6B → 合计33B ✅
    "digest": "财富盈活升级方向钱能拿走传承确定性测评",  # 42B OK
    "content": """<p>友邦6月1日出了新品...</p>""",  # HTML 正文
    "thumb_media_id": existing_thumb,   # 必须是 XDSx... 前缀
    "need_open_comment": 1,
    "only_fans_can_comment": 0
}

# Step 4: 推送草稿
create_url = f'https://api.weixin.qq.com/cgi-bin/draft/add?access_token={token}'
r2 = requests.post(create_url, json={"articles": [article]}, timeout=15)
result = r2.json()
#成功: {"media_id": "XDSx...", "item": [{"index": 0, "ad_count": 0}]}
# 失败: {"errcode": N, "errmsg": "..."}
print(json.dumps(result, indent=2, ensure_ascii=False))
```

---

## 关键错误码排查

| errcode | 含义 | 解决方法 |
|---------|------|---------|
| 40001 | token 无效/过期 | 重新获取 token，有效期7200秒 |
| 40007 | thumb_media_id 无效 | 必须用草稿箱已有的 XDSx... 前缀ID |
| 40066 | URL 无效 | 上传接口地址写错了，核对 endpoint |
| 41005 | media data missing | 正文图片用 `requests.post(url, files={})` |
| 45003 | title 超限 | title_bytes > 27B，缩短标题 |
| 45004 | digest/description 超限 | digest_bytes > ~120B，缩短摘要 |
| 45110 | author 超限 | author_bytes单独超限，或 title+author > 33B |
| 40164 | IP 不在白名单 | 添加 111.229.192.217 到白名单 |

---

## 封面图完整流程（如需新上传）

```python
# 封面图必须先上传到草稿箱（用 add_material 获取 XDSx 前缀 ID）
# 注意：material/add_material 返回的 media_id 是 f61mr... 前缀（临时素材），不是 XDSx...
# 正确做法：从草稿箱已有文章复制其 thumb_media_id，不要自己上传新的

# 如必须上传新封面图（需用草稿箱里已有的 XDSx... ID）：
# 1.手动在微信后台草稿箱上传图片
# 2. 拿到其 media_id（XDSx... 前缀）
# 3. 用这个 ID 作为 thumb_media_id
```

---

## Notion 状态更新

草稿发布成功后，同步更新 Notion 文章库状态：
```
PATCH https://api.notion.com/v1/pages/{PAGE_ID}
{"properties": {"状态": {"select": {"name": "已发布"}}}}
```